using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
public class DialougeBoxAutomatic : MonoBehaviour
{
    public TextMeshProUGUI textMeshPro;
    public string[] line;
    public float textspeed;
    private int index;
    // Start is called before the first frame update
    void Start()
    {
        textMeshPro.text = string.Empty;
        StartDialogue();
    }

    // Update is called once per frame
    void Update()
    {
            if (textMeshPro.text == line[index])
            {
                NextLine();
            }
    }
    void StartDialogue()
    {
        index = 0;
        StartCoroutine(TypeLine());
    }
    IEnumerator TypeLine()
    {
        foreach (char c in line[index].ToCharArray())
        {
            textMeshPro.text += c;
            yield return new WaitForSeconds(textspeed);
        }
    }
    void NextLine()
    {
        if (index < line.Length - 1)
        {
            index++;
            textMeshPro.text = string.Empty;
            StartCoroutine(TypeLine());
        }
    }
}
