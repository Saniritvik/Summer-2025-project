using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Respawn : MonoBehaviour
{
    private Vector3 respawn;
    public Vector3 checkPoint;
    // Start is called before the first frame update
    void Start()
    {
        respawn = new Vector3(1, 1, 0);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("PlayerOne") || collision.gameObject.CompareTag("PlayerTwo"))
        {
            collision.gameObject.transform.position = respawn;
        }
    }
    public void setCheckPoint()
    {
        respawn = checkPoint;
    }
}
