using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UIElements;

public class PlayerTwo : MonoBehaviour
{
    public int speed;
    public float jumpPower;
    private Rigidbody2D rb;
    private Vector2 moveDirection;
    private bool isGrounded;
    private PlayerManager PlayerManagerer;
    public GameObject UIManager;
    public Animator animator;
    public AudioSource walking;
    public Transform groundCheck;
    public LayerMask groundLayer;
    // Start is called before the first frame update
    void Start()
    {
        PlayerManagerer = UIManager.GetComponent<PlayerManager>();
        rb = GetComponent<Rigidbody2D>();
        playerSpawnPoint();
    }

    // Update is called once per frame
    void Update()
    {
        isGrounded = Physics2D.OverlapCapsule(groundCheck.position, new Vector2(0.3f, 0.1f), CapsuleDirection2D.Horizontal, 0, groundLayer);
        if (PlayerManagerer.AllowMove)
        {
            moveDirection.x = Input.GetAxisRaw("HorizontalTwo");
            if (Input.GetButtonDown("VerticalTwo") && isGrounded)
            {
                rb.AddForce(new Vector2(rb.velocity.x, jumpPower));
            }
        }
        else if (!PlayerManagerer.AllowMove)
        {
            moveDirection.x = 0;
        }
        animator.SetFloat("speed", Mathf.Abs(moveDirection.x));
        rb.velocity = new Vector2(moveDirection.x * speed, rb.velocity.y);
        if ((moveDirection.x != 0) && isGrounded)
        {
            if (!walking.isPlaying)
            {
                walking.Play();
            }
        }
        if(moveDirection.x == 0)
        {
        walking.Stop();
        }
       

    }

    private void playerSpawnPoint()
    {
        transform.position = new Vector3(116, -9, 1);
    }
}
