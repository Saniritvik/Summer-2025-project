using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    public Transform ExitDoor;
    private Vector3 Exit;
    private GameObject playerOne;
    private GameObject playerTwo;
    // Start is called before the first frame update
    void Start()
    {
        Exit = ExitDoor.position;
        playerOne = GameObject.FindWithTag("PlayerOne");
        playerTwo = GameObject.FindWithTag("PlayerTwo");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OpenDoorPlayerOne()
    {
        playerOne.transform.position = Exit;
            
    }
    public void OpenDoorPlayerTwo()
    {
        playerTwo.transform.position = Exit;
    }
}
